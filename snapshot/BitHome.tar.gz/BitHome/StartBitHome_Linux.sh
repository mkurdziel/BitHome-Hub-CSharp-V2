#!/bin/sh

nohup mono BitHome.exe &
