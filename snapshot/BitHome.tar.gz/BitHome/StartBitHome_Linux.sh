#!/bin/sh

nohup mono `pwd`/BitHome.exe &
